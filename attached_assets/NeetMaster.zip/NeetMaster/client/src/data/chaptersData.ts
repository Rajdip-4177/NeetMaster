export interface Chapter {
  id: string;
  subjectId: string;
  title: string;
  chapterNumber: number;
  description: string;
  topicCount: number;
  testCount: number;
}

export const chapters: Chapter[] = [
  // Biology Chapters
  {
    id: "cell-the-unit-of-life",
    subjectId: "biology",
    title: "Cell - The Unit of Life",
    chapterNumber: 1,
    description: "Study the structure and functions of cell organelles and cellular organization.",
    topicCount: 10,
    testCount: 10
  },
  {
    id: "human-physiology",
    subjectId: "biology",
    title: "Human Physiology",
    chapterNumber: 2,
    description: "Learn about the functioning of human body systems including digestion, respiration, and circulation.",
    topicCount: 12,
    testCount: 10
  },
  {
    id: "genetics",
    subjectId: "biology",
    title: "Genetics",
    chapterNumber: 3,
    description: "Understand principles of inheritance, genetic disorders, and molecular basis of inheritance.",
    topicCount: 8,
    testCount: 8
  },
  {
    id: "plant-physiology",
    subjectId: "biology",
    title: "Plant Physiology",
    chapterNumber: 4,
    description: "Explore plant growth, development, hormones and their responses to environment.",
    topicCount: 9,
    testCount: 8
  },
  {
    id: "ecology",
    subjectId: "biology",
    title: "Ecology and Environment",
    chapterNumber: 5,
    description: "Study ecosystems, biodiversity, environmental issues and conservation strategies.",
    topicCount: 7,
    testCount: 7
  },
  
  // Physics Chapters
  {
    id: "mechanics",
    subjectId: "physics",
    title: "Mechanics",
    chapterNumber: 1,
    description: "Learn about motion, forces, energy, and momentum in classical mechanics.",
    topicCount: 12,
    testCount: 10
  },
  {
    id: "thermodynamics",
    subjectId: "physics",
    title: "Thermodynamics",
    chapterNumber: 2,
    description: "Study heat, temperature, energy transfer and the laws of thermodynamics.",
    topicCount: 8,
    testCount: 7
  },
  {
    id: "electromagnetism",
    subjectId: "physics",
    title: "Electromagnetism",
    chapterNumber: 3,
    description: "Understand electric and magnetic fields, electromagnetic induction and their applications.",
    topicCount: 10,
    testCount: 9
  },
  {
    id: "optics",
    subjectId: "physics",
    title: "Optics",
    chapterNumber: 4,
    description: "Explore reflection, refraction, dispersion of light and optical instruments.",
    topicCount: 9,
    testCount: 8
  },
  {
    id: "modern-physics",
    subjectId: "physics",
    title: "Modern Physics",
    chapterNumber: 5,
    description: "Dive into quantum theory, atomic structure, nuclear physics and relativity.",
    topicCount: 7,
    testCount: 6
  },
  
  // Chemistry Chapters
  {
    id: "atomic-structure",
    subjectId: "chemistry",
    title: "Atomic Structure",
    chapterNumber: 1,
    description: "Understand the structure of atoms, isotopes, and electronic configuration.",
    topicCount: 8,
    testCount: 7
  },
  {
    id: "chemical-bonding",
    subjectId: "chemistry",
    title: "Chemical Bonding",
    chapterNumber: 2,
    description: "Learn about various types of chemical bonds and their properties.",
    topicCount: 7,
    testCount: 6
  },
  {
    id: "organic-chemistry",
    subjectId: "chemistry",
    title: "Organic Chemistry Basics",
    chapterNumber: 3,
    description: "Study fundamental concepts of organic chemistry, functional groups and reactions.",
    topicCount: 10,
    testCount: 9
  },
  {
    id: "solutions",
    subjectId: "chemistry",
    title: "Solutions",
    chapterNumber: 4,
    description: "Explore types of solutions, concentration and colligative properties.",
    topicCount: 6,
    testCount: 5
  },
  {
    id: "electrochemistry",
    subjectId: "chemistry",
    title: "Electrochemistry",
    chapterNumber: 5,
    description: "Understand redox reactions, electrochemical cells and electrolysis.",
    topicCount: 7,
    testCount: 6
  }
];

export const getChaptersBySubject = (subjectId: string): Chapter[] => {
  return chapters.filter(chapter => chapter.subjectId === subjectId);
};

export const getChapterById = (chapterId: string): Chapter | undefined => {
  return chapters.find(chapter => chapter.id === chapterId);
};
