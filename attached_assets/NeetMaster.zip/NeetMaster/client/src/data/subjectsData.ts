export interface Subject {
  id: string;
  name: string;
  description: string;
  icon: string;
  imageSrc: string;
  primaryColor: string;
  secondaryColor: string;
  topicCount: number;
  testCount: number;
}

export const subjects: Subject[] = [
  {
    id: "biology",
    name: "Biology",
    description: "Master biological concepts from cell biology to human physiology with comprehensive chapter-wise preparation.",
    icon: "fas fa-leaf",
    imageSrc: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    primaryColor: "#10B981",
    secondaryColor: "#D1FAE5",
    topicCount: 30,
    testCount: 25
  },
  {
    id: "physics",
    name: "Physics",
    description: "From mechanics to modern physics, build a strong foundation with practice tests and comprehensive notes.",
    icon: "fas fa-atom",
    imageSrc: "https://images.unsplash.com/photo-1636466497217-26a5146bd5d1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    primaryColor: "#3B82F6",
    secondaryColor: "#DBEAFE",
    topicCount: 28,
    testCount: 24
  },
  {
    id: "chemistry",
    name: "Chemistry",
    description: "Cover organic, inorganic, and physical chemistry with targeted practice and NCERT solutions.",
    icon: "fas fa-flask",
    imageSrc: "https://images.unsplash.com/photo-1603126857599-f6e157fa2fe6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    primaryColor: "#8B5CF6",
    secondaryColor: "#EDE9FE",
    topicCount: 25,
    testCount: 22
  }
];

export const getSubjectById = (id: string): Subject | undefined => {
  return subjects.find(subject => subject.id === id);
};
