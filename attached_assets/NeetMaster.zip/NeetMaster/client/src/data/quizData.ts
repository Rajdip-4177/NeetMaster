import { Question } from "@/context/QuizContext";

export interface Test {
  id: number;
  chapterId: string;
  title: string;
  description: string;
  questionCount: number;
  timeLimit: number;
  difficulty: number;
}

export const tests: Test[] = [
  // Cell - The Unit of Life Tests
  {
    id: 1,
    chapterId: "cell-the-unit-of-life",
    title: "Cell Structure & Organization",
    description: "Test your knowledge about basic cell structure and organization.",
    questionCount: 25,
    timeLimit: 25 * 60, // 25 minutes in seconds
    difficulty: 3
  },
  {
    id: 2,
    chapterId: "cell-the-unit-of-life",
    title: "Cell Membrane & Transport",
    description: "Questions on cell membrane structure and transport mechanisms.",
    questionCount: 25,
    timeLimit: 25 * 60,
    difficulty: 4
  },
  
  // Human Physiology Tests
  {
    id: 3,
    chapterId: "human-physiology",
    title: "Digestive System",
    description: "Test on digestive enzymes, organs and their functions.",
    questionCount: 25,
    timeLimit: 25 * 60,
    difficulty: 3
  },
  {
    id: 4,
    chapterId: "human-physiology",
    title: "Respiratory System",
    description: "Questions on breathing mechanism and gas exchange.",
    questionCount: 25,
    timeLimit: 25 * 60,
    difficulty: 4
  }
];

export const getTestsByChapter = (chapterId: string): Test[] => {
  return tests.filter(test => test.chapterId === chapterId);
};

export const getTestById = (testId: number): Test | undefined => {
  return tests.find(test => test.id === testId);
};

// Sample questions for demonstration
export const getQuestionsByTest = (testId: number): Question[] => {
  switch (testId) {
    case 1:
      return [
        {
          id: 1,
          questionText: "Which of the following organelles is known as the 'powerhouse of the cell' and is responsible for cellular respiration?",
          options: [
            { id: "a", text: "Mitochondria" },
            { id: "b", text: "Golgi apparatus" },
            { id: "c", text: "Endoplasmic reticulum" },
            { id: "d", text: "Lysosome" }
          ],
          correctOptionId: "a",
          explanation: "Mitochondria are called the powerhouse of the cell because they generate most of the cell's supply of adenosine triphosphate (ATP) through the process of cellular respiration. They have their own DNA and can replicate independently within the cell.",
          selectedOptionId: null,
          isMarkedForReview: false,
          isBookmarked: false,
          status: "unanswered"
        },
        {
          id: 2,
          questionText: "Which organelle is responsible for protein synthesis in the cell?",
          options: [
            { id: "a", text: "Ribosome" },
            { id: "b", text: "Golgi apparatus" },
            { id: "c", text: "Lysosome" },
            { id: "d", text: "Peroxisome" }
          ],
          correctOptionId: "a",
          explanation: "Ribosomes are the cellular structures responsible for protein synthesis. They can be found floating freely in the cytoplasm or attached to the endoplasmic reticulum. The Golgi apparatus is involved in processing, packaging, and transporting proteins, but not in their synthesis.",
          selectedOptionId: null,
          isMarkedForReview: false,
          isBookmarked: false,
          status: "unanswered"
        },
        {
          id: 3,
          questionText: "Which of the following is NOT a function of the cell membrane?",
          options: [
            { id: "a", text: "Protein synthesis" },
            { id: "b", text: "Selective permeability" },
            { id: "c", text: "Cell recognition" },
            { id: "d", text: "Physical barrier" }
          ],
          correctOptionId: "a",
          explanation: "The cell membrane is not involved in protein synthesis, which primarily occurs at ribosomes. Cell membranes provide a physical barrier, allow for selective permeability, and contain proteins that function in cell recognition.",
          selectedOptionId: null,
          isMarkedForReview: false,
          isBookmarked: false,
          status: "unanswered"
        },
        {
          id: 4,
          questionText: "Which organelle contains hydrolytic enzymes for intracellular digestion?",
          options: [
            { id: "a", text: "Lysosome" },
            { id: "b", text: "Peroxisome" },
            { id: "c", text: "Vacuole" },
            { id: "d", text: "Endoplasmic reticulum" }
          ],
          correctOptionId: "a",
          explanation: "Lysosomes contain hydrolytic enzymes that break down macromolecules, cellular debris, and foreign materials within the cell. They function as the digestive system of the cell.",
          selectedOptionId: null,
          isMarkedForReview: false,
          isBookmarked: false,
          status: "unanswered"
        },
        {
          id: 5,
          questionText: "What is the primary function of the chloroplast in plant cells?",
          options: [
            { id: "a", text: "Photosynthesis" },
            { id: "b", text: "Cellular respiration" },
            { id: "c", text: "Protein synthesis" },
            { id: "d", text: "Lipid metabolism" }
          ],
          correctOptionId: "a",
          explanation: "Chloroplasts are organelles in plant cells that contain the green pigment chlorophyll and are responsible for photosynthesis, the process by which light energy is converted into chemical energy in the form of glucose.",
          selectedOptionId: null,
          isMarkedForReview: false,
          isBookmarked: false,
          status: "unanswered"
        }
      ];
    default:
      // Return generic questions for other tests
      return Array.from({ length: 25 }, (_, i) => ({
        id: i + 1,
        questionText: `Sample question ${i + 1} for test ${testId}`,
        options: [
          { id: "a", text: `Option A for question ${i + 1}` },
          { id: "b", text: `Option B for question ${i + 1}` },
          { id: "c", text: `Option C for question ${i + 1}` },
          { id: "d", text: `Option D for question ${i + 1}` }
        ],
        correctOptionId: "a",
        explanation: `This is an explanation for sample question ${i + 1}.`,
        selectedOptionId: null,
        isMarkedForReview: false,
        isBookmarked: false,
        status: "unanswered"
      }));
  }
};

// Performance data for result page
export interface TopicPerformance {
  topic: string;
  percentage: number;
}

export interface StrengthWeakness {
  strong: string[];
  weak: string[];
}

export const getTopicPerformance = (testId: number): TopicPerformance[] => {
  return [
    { topic: "Cell Membrane", percentage: 90 },
    { topic: "Mitochondria", percentage: 75 },
    { topic: "Cellular Respiration", percentage: 65 },
    { topic: "Cell Division", percentage: 55 }
  ];
};

export const getStrengthsAndWeaknesses = (testId: number): StrengthWeakness => {
  return {
    strong: [
      "Cell Membrane Structure",
      "Mitochondrial Function",
      "Endoplasmic Reticulum"
    ],
    weak: [
      "Cell Division Process",
      "Golgi Apparatus Function",
      "Cellular Respiration Cycle"
    ]
  };
};
