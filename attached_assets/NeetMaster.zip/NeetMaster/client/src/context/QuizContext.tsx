import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from "react";

export interface QuestionOption {
  id: string;
  text: string;
}

export interface Question {
  id: number;
  questionText: string;
  options: QuestionOption[];
  correctOptionId: string;
  explanation: string;
  selectedOptionId: string | null;
  isMarkedForReview: boolean;
  isBookmarked: boolean;
  status: "unanswered" | "answered" | "reviewed" | "answered+reviewed";
}

export interface QuizResult {
  score: number;
  totalScore: number;
  correctAnswers: number;
  incorrectAnswers: number;
  skippedAnswers: number;
  timeTaken: number;
  timeAllowed: number;
}

interface QuizContextType {
  questions: Question[];
  currentQuestionIndex: number;
  quizTime: number;
  timeRemaining: number;
  isQuizCompleted: boolean;
  quizResult: QuizResult | null;
  bookmarkedQuestions: number[];
  setQuestions: (questions: Question[]) => void;
  selectOption: (questionId: number, optionId: string) => void;
  markForReview: (questionId: number) => void;
  goToNextQuestion: () => void;
  goToPreviousQuestion: () => void;
  jumpToQuestion: (index: number) => void;
  toggleBookmark: (questionId: number) => void;
  startQuiz: (timeLimit: number, questionsData: Question[]) => void;
  submitQuiz: () => void;
  loadBookmarks: () => void;
}

const QuizContext = createContext<QuizContextType | undefined>(undefined);

export const useQuiz = () => {
  const context = useContext(QuizContext);
  if (!context) {
    throw new Error("useQuiz must be used within a QuizProvider");
  }
  return context;
};

interface QuizProviderProps {
  children: ReactNode;
}

export const QuizProvider = ({ children }: QuizProviderProps) => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [quizTime, setQuizTime] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [isQuizCompleted, setIsQuizCompleted] = useState(false);
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null);
  const [bookmarkedQuestions, setBookmarkedQuestions] = useState<number[]>([]);
  const [timerIntervalId, setTimerIntervalId] = useState<NodeJS.Timeout | null>(null);

  // Load bookmarks only once when component mounts
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('bookmarkedQuestions') || '[]');
      setBookmarkedQuestions(saved);
    } catch (error) {
      console.error('Failed to load bookmarks', error);
      setBookmarkedQuestions([]);
    }
    
    // Cleanup timer on unmount
    return () => {
      if (timerIntervalId) clearInterval(timerIntervalId);
    };
  }, []);

  const loadBookmarks = useCallback(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('bookmarkedQuestions') || '[]');
      setBookmarkedQuestions(saved);
    } catch (error) {
      console.error('Failed to load bookmarks', error);
      setBookmarkedQuestions([]);
    }
  }, []);

  const startQuiz = useCallback((timeLimit: number, questionsData: Question[]) => {
    // Initialize questions with bookmarked status
    const questionsWithBookmarks = questionsData.map(q => ({
      ...q,
      isBookmarked: bookmarkedQuestions.includes(q.id)
    }));
    
    setQuestions(questionsWithBookmarks);
    setCurrentQuestionIndex(0);
    setQuizTime(timeLimit);
    setTimeRemaining(timeLimit);
    setIsQuizCompleted(false);
    setQuizResult(null);
    
    // Clear any existing interval
    if (timerIntervalId) {
      clearInterval(timerIntervalId);
      setTimerIntervalId(null);
    }
    
    // Start the timer
    const intervalId = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(intervalId);
          // Call submitQuiz here for automatic submission
          submitQuiz();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    setTimerIntervalId(intervalId);
  }, [bookmarkedQuestions]);

  const selectOption = useCallback((questionId: number, optionId: string) => {
    setQuestions(prev => 
      prev.map(q => 
        q.id === questionId 
          ? { 
              ...q, 
              selectedOptionId: optionId, 
              status: q.isMarkedForReview ? 'answered+reviewed' : 'answered' 
            } 
          : q
      )
    );
  }, []);

  const markForReview = useCallback((questionId: number) => {
    setQuestions(prev => 
      prev.map(q => 
        q.id === questionId 
          ? { 
              ...q, 
              isMarkedForReview: !q.isMarkedForReview,
              status: q.selectedOptionId 
                ? (!q.isMarkedForReview ? 'answered+reviewed' : 'answered') 
                : (!q.isMarkedForReview ? 'reviewed' : 'unanswered')
            } 
          : q
      )
    );
  }, []);

  const goToNextQuestion = useCallback(() => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  }, [currentQuestionIndex, questions.length]);

  const goToPreviousQuestion = useCallback(() => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  }, [currentQuestionIndex]);

  const jumpToQuestion = useCallback((index: number) => {
    if (index >= 0 && index < questions.length) {
      setCurrentQuestionIndex(index);
    }
  }, [questions.length]);

  const toggleBookmark = useCallback((questionId: number) => {
    // Update bookmarked questions array
    setBookmarkedQuestions(prev => {
      const isBookmarked = prev.includes(questionId);
      const newBookmarks = isBookmarked
        ? prev.filter(id => id !== questionId)
        : [...prev, questionId];
      
      // Save to localStorage
      localStorage.setItem('bookmarkedQuestions', JSON.stringify(newBookmarks));
      return newBookmarks;
    });

    // Also update the bookmark status in the questions state if in a quiz
    if (questions.length > 0) {
      setQuestions(prev => 
        prev.map(q => 
          q.id === questionId 
            ? { ...q, isBookmarked: !q.isBookmarked }
            : q
        )
      );
    }
  }, [questions.length]);

  const submitQuiz = useCallback(() => {
    // Stop the timer
    if (timerIntervalId) {
      clearInterval(timerIntervalId);
      setTimerIntervalId(null);
    }
    
    // Calculate results
    let score = 0;
    let correctCount = 0;
    let incorrectCount = 0;
    let skippedCount = 0;

    questions.forEach(q => {
      if (!q.selectedOptionId) {
        skippedCount++;
      } else if (q.selectedOptionId === q.correctOptionId) {
        score += 4;
        correctCount++;
      } else {
        score -= 1;
        incorrectCount++;
      }
    });

    const timeTaken = quizTime - timeRemaining;
    
    setQuizResult({
      score: score,
      totalScore: questions.length * 4,
      correctAnswers: correctCount,
      incorrectAnswers: incorrectCount,
      skippedAnswers: skippedCount,
      timeTaken: timeTaken,
      timeAllowed: quizTime
    });
    
    setIsQuizCompleted(true);
  }, [questions, quizTime, timeRemaining, timerIntervalId]);

  return (
    <QuizContext.Provider value={{
      questions,
      currentQuestionIndex,
      quizTime,
      timeRemaining,
      isQuizCompleted,
      quizResult,
      bookmarkedQuestions,
      setQuestions,
      selectOption,
      markForReview,
      goToNextQuestion,
      goToPreviousQuestion,
      jumpToQuestion,
      toggleBookmark,
      startQuiz,
      submitQuiz,
      loadBookmarks
    }}>
      {children}
    </QuizContext.Provider>
  );
};
