import { Link } from "wouter";
import { Test } from "@/data/quizData";

interface TestCardProps {
  test: Test;
  subject: string;
  chapter: string;
  subjectColor: string;
  subjectSecondaryColor: string;
}

const TestCard = ({ test, subject, chapter, subjectColor, subjectSecondaryColor }: TestCardProps) => {
  // Render stars based on difficulty (1-5)
  const renderDifficultyStars = () => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <i 
          key={i} 
          className={`fas fa-star ${i <= test.difficulty ? 'text-yellow-400' : 'text-gray-300'}`}
        ></i>
      );
    }
    return stars;
  };

  // Format time in minutes
  const formatTime = (seconds: number) => {
    return `${Math.floor(seconds / 60)} minutes`;
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 hover:border-[#10B981] transition-all duration-300">
      <div className="h-10" style={{ backgroundColor: subjectColor }}></div>
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-lg font-semibold text-gray-900">{test.title}</h3>
          <span 
            className="text-xs px-2 py-1 rounded-full"
            style={{ 
              backgroundColor: subjectSecondaryColor,
              color: subjectColor
            }}
          >
            Test {test.id}
          </span>
        </div>
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Questions</span>
            <span className="font-medium">{test.questionCount} MCQs</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Time Limit</span>
            <span className="font-medium">{formatTime(test.timeLimit)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Difficulty</span>
            <div className="flex items-center">
              {renderDifficultyStars()}
            </div>
          </div>
        </div>
        <Link href={`/${subject}/${chapter}/test/${test.id}`}>
          <button 
            className="mt-4 text-white py-2 px-4 rounded-md w-full flex items-center justify-center"
            style={{ 
              backgroundColor: subjectColor,
              ':hover': { opacity: 0.9 }
            } as React.CSSProperties}
          >
            <i className="fas fa-play-circle mr-2"></i> Start Test
          </button>
        </Link>
      </div>
    </div>
  );
};

export default TestCard;
