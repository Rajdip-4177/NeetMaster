import { Link } from "wouter";
import { Subject } from "@/data/subjectsData";

interface SubjectCardProps {
  subject: Subject;
}

const SubjectCard = ({ subject }: SubjectCardProps) => {
  return (
    <Link href={`/${subject.id}`} className="group">
      <div 
        className="bg-white rounded-lg shadow-md overflow-hidden border-2 border-transparent hover:border-[#10B981] transition-all duration-300 h-full flex flex-col"
        style={{ 
          borderColor: 'transparent', 
          '--hover-border-color': subject.primaryColor 
        } as React.CSSProperties}
      >
        <div 
          className="h-48 flex items-center justify-center"
          style={{ backgroundColor: subject.secondaryColor }}
        >
          <img src={subject.imageSrc} alt={subject.name} className="h-32 object-contain" />
        </div>
        <div className="p-6 flex-grow">
          <div className="flex items-center mb-2">
            <span 
              className="w-8 h-8 rounded-full text-white flex items-center justify-center mr-3"
              style={{ backgroundColor: subject.primaryColor }}
            >
              <i className={subject.icon}></i>
            </span>
            <h2 className="text-xl font-semibold text-gray-900">{subject.name}</h2>
          </div>
          <p className="text-gray-600 mb-4">{subject.description}</p>
          <div 
            className="font-medium group-hover:underline flex items-center mt-auto"
            style={{ color: subject.primaryColor }}
          >
            Explore chapters <i className="fas fa-arrow-right ml-1"></i>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default SubjectCard;
