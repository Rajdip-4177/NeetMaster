import { useQuiz } from "@/context/QuizContext";

interface QuestionBoxProps {
  subjectColor: string;
}

const QuestionBox = ({ subjectColor }: QuestionBoxProps) => {
  const { 
    questions, 
    currentQuestionIndex, 
    selectOption, 
    markForReview, 
    goToNextQuestion, 
    goToPreviousQuestion, 
    submitQuiz,
    toggleBookmark
  } = useQuiz();
  
  if (!questions || questions.length === 0 || !questions[currentQuestionIndex]) {
    return <div className="bg-white shadow-md rounded-lg p-6">Loading questions...</div>;
  }
  
  const currentQuestion = questions[currentQuestionIndex];
  const isFirstQuestion = currentQuestionIndex === 0;
  const isLastQuestion = currentQuestionIndex === questions.length - 1;
  
  const handleOptionSelect = (optionId: string) => {
    selectOption(currentQuestion.id, optionId);
  };
  
  const handleReviewToggle = () => {
    markForReview(currentQuestion.id);
  };
  
  const handleBookmarkToggle = () => {
    toggleBookmark(currentQuestion.id);
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <span 
            className="text-white rounded-full w-8 h-8 flex items-center justify-center font-semibold mr-3"
            style={{ backgroundColor: subjectColor }}
          >
            {currentQuestionIndex + 1}
          </span>
          <h2 className="text-lg font-semibold text-gray-900">
            Question {currentQuestionIndex + 1} of {questions.length}
          </h2>
        </div>
        <button 
          className={`text-gray-400 hover:text-yellow-500 ${currentQuestion.isBookmarked ? 'text-yellow-400' : ''}`}
          onClick={handleBookmarkToggle}
        >
          <i className={`${currentQuestion.isBookmarked ? 'fas' : 'far'} fa-bookmark text-xl`}></i>
        </button>
      </div>

      <div className="mb-8">
        <p className="text-gray-800 text-lg mb-6">{currentQuestion.questionText}</p>
        
        <div className="space-y-4">
          {currentQuestion.options.map((option) => (
            <label 
              key={option.id}
              className={`block relative border rounded-lg p-4 cursor-pointer transition-colors duration-200 ${
                currentQuestion.selectedOptionId === option.id 
                  ? 'border-2' 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              style={{ 
                borderColor: currentQuestion.selectedOptionId === option.id ? subjectColor : undefined,
              }}
            >
              <input 
                type="radio" 
                name={`q${currentQuestion.id}`} 
                className="absolute opacity-0"
                checked={currentQuestion.selectedOptionId === option.id}
                onChange={() => handleOptionSelect(option.id)}
              />
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-0.5">
                  <div className="w-5 h-5 border border-gray-300 rounded-full flex items-center justify-center">
                    {currentQuestion.selectedOptionId === option.id && (
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: subjectColor }}
                      ></div>
                    )}
                  </div>
                </div>
                <div className="ml-3">
                  <span className="text-gray-800">{option.text}</span>
                </div>
              </div>
            </label>
          ))}
        </div>
      </div>

      <div className="flex justify-between items-center border-t pt-4">
        <button 
          className={`bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 px-4 rounded-md flex items-center ${
            currentQuestion.isMarkedForReview ? 'bg-purple-100 text-purple-700' : ''
          }`}
          onClick={handleReviewToggle}
        >
          <i className="fas fa-flag mr-2"></i> 
          {currentQuestion.isMarkedForReview ? 'Remove Review Flag' : 'Mark for Review'}
        </button>
        <div className="flex space-x-3">
          <button 
            className={`bg-gray-200 hover:bg-gray-300 text-gray-700 py-2 px-4 rounded-md flex items-center ${isFirstQuestion ? 'opacity-50 cursor-not-allowed' : ''}`}
            onClick={goToPreviousQuestion}
            disabled={isFirstQuestion}
          >
            <i className="fas fa-arrow-left mr-2"></i> Previous
          </button>
          {isLastQuestion ? (
            <button 
              className="text-white py-2 px-4 rounded-md flex items-center hover:opacity-90"
              style={{ backgroundColor: subjectColor }}
              onClick={submitQuiz}
            >
              Submit Test <i className="fas fa-check ml-2"></i>
            </button>
          ) : (
            <button 
              className="text-white py-2 px-4 rounded-md flex items-center hover:opacity-90"
              style={{ backgroundColor: subjectColor }}
              onClick={goToNextQuestion}
            >
              Save & Next <i className="fas fa-arrow-right ml-2"></i>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuestionBox;
