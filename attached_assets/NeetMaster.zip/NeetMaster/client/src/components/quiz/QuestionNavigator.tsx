import { useQuiz } from "@/context/QuizContext";

interface QuestionNavigatorProps {
  subjectColor: string;
}

const QuestionNavigator = ({ subjectColor }: QuestionNavigatorProps) => {
  const { 
    questions, 
    currentQuestionIndex, 
    jumpToQuestion,
    submitQuiz
  } = useQuiz();
  
  if (!questions || questions.length === 0) {
    return <div className="bg-white shadow-md rounded-lg p-4">Loading navigator...</div>;
  }
  
  // Count questions by status for summary
  const summary = {
    answered: questions.filter(q => q.status === 'answered' || q.status === 'answered+reviewed').length,
    notAnswered: questions.filter(q => q.status === 'unanswered').length,
    reviewed: questions.filter(q => q.status === 'reviewed' || q.status === 'answered+reviewed').length,
    notVisited: 0 // In this implementation all questions are "visited"
  };

  // Get button background color based on question status
  const getButtonStyle = (status: string, isCurrentQuestion: boolean) => {
    const styles = {
      bg: '',
      text: '',
      hover: '',
      border: isCurrentQuestion ? `border-2 border-black` : ''
    };
    
    switch (status) {
      case 'answered':
        styles.bg = 'bg-green-100';
        styles.text = 'text-green-700';
        styles.hover = 'hover:bg-green-200';
        break;
      case 'unanswered':
        styles.bg = 'bg-red-100';
        styles.text = 'text-red-700';
        styles.hover = 'hover:bg-red-200';
        break;
      case 'reviewed':
        styles.bg = 'bg-purple-100';
        styles.text = 'text-purple-700';
        styles.hover = 'hover:bg-purple-200';
        break;
      case 'answered+reviewed':
        styles.bg = 'bg-gradient-to-br from-green-100 to-purple-100';
        styles.text = 'text-purple-700';
        styles.hover = 'hover:from-green-200 hover:to-purple-200';
        break;
      default:
        styles.bg = 'bg-gray-100';
        styles.text = 'text-gray-700';
        styles.hover = 'hover:bg-gray-200';
    }
    
    return styles;
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-4">
      <h3 className="text-lg font-semibold text-gray-900 mb-3">Question Navigator</h3>
      <div className="grid grid-cols-5 gap-2 mb-4">
        {questions.map((question, index) => {
          const isCurrentQuestion = index === currentQuestionIndex;
          const style = getButtonStyle(question.status, isCurrentQuestion);
          return (
            <button
              key={question.id}
              className={`h-9 w-9 rounded-md flex items-center justify-center text-sm font-medium 
                ${style.bg} ${style.text} ${style.hover} ${style.border} transition-colors`}
              onClick={() => jumpToQuestion(index)}
            >
              {index + 1}
            </button>
          );
        })}
      </div>

      <div className="border-t pt-4">
        <h4 className="text-sm font-medium text-gray-700 mb-2">Summary</h4>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
              <span className="text-sm text-gray-600">Answered</span>
            </div>
            <span className="text-sm font-medium text-gray-800">{summary.answered}</span>
          </div>
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
              <span className="text-sm text-gray-600">Not Answered</span>
            </div>
            <span className="text-sm font-medium text-gray-800">{summary.notAnswered}</span>
          </div>
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-purple-500 mr-2"></div>
              <span className="text-sm text-gray-600">Marked for Review</span>
            </div>
            <span className="text-sm font-medium text-gray-800">{summary.reviewed}</span>
          </div>
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-gray-300 mr-2"></div>
              <span className="text-sm text-gray-600">Not Visited</span>
            </div>
            <span className="text-sm font-medium text-gray-800">{summary.notVisited}</span>
          </div>
        </div>
      </div>

      <button 
        className="mt-6 text-white py-3 px-4 rounded-md w-full flex items-center justify-center hover:opacity-90"
        style={{ backgroundColor: subjectColor }}
        onClick={submitQuiz}
      >
        <i className="fas fa-check-circle mr-2"></i> Submit Test
      </button>
    </div>
  );
};

export default QuestionNavigator;
