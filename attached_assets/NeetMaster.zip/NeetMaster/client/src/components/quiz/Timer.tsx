import { useQuiz } from "@/context/QuizContext";

const Timer = () => {
  const { timeRemaining } = useQuiz();
  
  // Format seconds to MM:SS
  const formatTime = (seconds: number) => {
    if (seconds === undefined || seconds === null) return "00:00";
    
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  // Get color classes based on time remaining
  const getTimerColor = () => {
    if (timeRemaining <= 60) { // Last minute
      return "text-red-600";
    } else if (timeRemaining <= 300) { // Last 5 minutes
      return "text-yellow-600";
    }
    return "text-gray-800";
  };

  return (
    <div className="bg-gray-100 rounded-md px-4 py-2 flex items-center">
      <i className="fas fa-clock text-green-600 mr-2"></i>
      <span className={`font-mono text-lg font-semibold ${getTimerColor()}`}>
        {formatTime(timeRemaining)}
      </span>
      <span className="text-gray-500 ml-1 text-sm">remaining</span>
    </div>
  );
};

export default Timer;
