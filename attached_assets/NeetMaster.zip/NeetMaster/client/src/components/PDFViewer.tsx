interface PDFViewerProps {
  pdfType: 'notes' | 'ncert';
  subjectId: string;
  chapterId: string;
  primaryColor: string;
}

const PDFViewer = ({ pdfType, subjectId, chapterId, primaryColor }: PDFViewerProps) => {
  // In a real application, this would use react-pdf library to display actual PDFs
  // For this demo, we're just showing a placeholder
  
  const handleLoadPDF = () => {
    alert(`Loading ${pdfType} for ${subjectId}/${chapterId}. In a real app, this would load the actual PDF.`);
  };
  
  return (
    <div className="border rounded-lg bg-gray-50 p-4 h-96 flex flex-col items-center justify-center">
      <i className="fas fa-file-pdf text-6xl text-gray-400 mb-4"></i>
      <p className="text-gray-500 text-center mb-4">
        {pdfType === 'notes' 
          ? 'PDF viewer will be embedded here to display the notes'
          : 'NCERT PDF content will be embedded here for reference'}
      </p>
      <button 
        className="py-2 px-4 rounded-md"
        style={{ 
          backgroundColor: `${primaryColor}10`,
          color: primaryColor
        }}
        onClick={handleLoadPDF}
      >
        Load {pdfType === 'notes' ? 'PDF Content' : 'NCERT Content'}
      </button>
    </div>
  );
};

export default PDFViewer;
