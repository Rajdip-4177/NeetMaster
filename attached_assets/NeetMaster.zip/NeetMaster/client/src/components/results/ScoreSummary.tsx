import { QuizResult } from "@/context/QuizContext";

interface ScoreSummaryProps {
  quizResult: QuizResult;
  subjectColor: string;
  subjectSecondaryColor: string;
}

const ScoreSummary = ({ quizResult, subjectColor, subjectSecondaryColor }: ScoreSummaryProps) => {
  // Format seconds to MM:SS
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  // Calculate percentages
  const scorePercentage = Math.round((quizResult.score / quizResult.totalScore) * 100);
  const timePercentage = Math.round((quizResult.timeTaken / quizResult.timeAllowed) * 100);
  const correctPercentage = Math.round((quizResult.correctAnswers / (quizResult.correctAnswers + quizResult.incorrectAnswers + quizResult.skippedAnswers)) * 100);
  const incorrectPercentage = Math.round((quizResult.incorrectAnswers / (quizResult.correctAnswers + quizResult.incorrectAnswers + quizResult.skippedAnswers)) * 100);

  return (
    <div className="bg-white shadow-md rounded-lg p-6 mb-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="p-4 rounded-lg" style={{ backgroundColor: subjectSecondaryColor }}>
          <p className="text-sm font-medium mb-1" style={{ color: subjectColor }}>Your Score</p>
          <div className="flex items-end">
            <span className="text-3xl font-bold" style={{ color: subjectColor }}>
              {quizResult.score}
            </span>
            <span className="text-gray-500 ml-1 mb-1">/{quizResult.totalScore}</span>
          </div>
          <div className="flex items-center mt-2">
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="h-2.5 rounded-full" 
                style={{ width: `${scorePercentage}%`, backgroundColor: subjectColor }}
              ></div>
            </div>
            <span className="text-xs text-gray-500 ml-2">{scorePercentage}%</span>
          </div>
        </div>

        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-500 font-medium mb-1">Time Taken</p>
          <div className="flex items-end">
            <span className="text-2xl font-bold text-gray-900">
              {formatTime(quizResult.timeTaken)}
            </span>
            <span className="text-gray-500 ml-1 mb-1">/{formatTime(quizResult.timeAllowed)}</span>
          </div>
          <div className="flex items-center mt-2">
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div className="bg-gray-700 h-2.5 rounded-full" style={{ width: `${timePercentage}%` }}></div>
            </div>
            <span className="text-xs text-gray-500 ml-2">{timePercentage}%</span>
          </div>
        </div>

        <div className="p-4 bg-green-50 rounded-lg">
          <p className="text-sm text-green-600 font-medium mb-1">Correct Answers</p>
          <div className="flex items-end">
            <span className="text-3xl font-bold text-green-600">{quizResult.correctAnswers}</span>
            <span className="text-gray-500 ml-1 mb-1">/{quizResult.correctAnswers + quizResult.incorrectAnswers + quizResult.skippedAnswers}</span>
          </div>
          <div className="flex items-center mt-2">
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div className="bg-green-500 h-2.5 rounded-full" style={{ width: `${correctPercentage}%` }}></div>
            </div>
            <span className="text-xs text-gray-500 ml-2">{correctPercentage}%</span>
          </div>
        </div>

        <div className="p-4 bg-red-50 rounded-lg">
          <p className="text-sm text-red-600 font-medium mb-1">Incorrect Answers</p>
          <div className="flex items-end">
            <span className="text-3xl font-bold text-red-600">{quizResult.incorrectAnswers}</span>
            <span className="text-gray-500 ml-1 mb-1">/{quizResult.correctAnswers + quizResult.incorrectAnswers + quizResult.skippedAnswers}</span>
          </div>
          <div className="flex items-center mt-2">
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div className="bg-red-500 h-2.5 rounded-full" style={{ width: `${incorrectPercentage}%` }}></div>
            </div>
            <span className="text-xs text-gray-500 ml-2">{incorrectPercentage}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScoreSummary;
