import { TopicPerformance, StrengthWeakness } from "@/data/quizData";

interface PerformanceAnalysisProps {
  topicPerformance: TopicPerformance[];
  strengthsWeaknesses: StrengthWeakness;
  subjectColor: string;
}

const PerformanceAnalysis = ({ 
  topicPerformance, 
  strengthsWeaknesses, 
  subjectColor 
}: PerformanceAnalysisProps) => {
  return (
    <div className="bg-white shadow-md rounded-lg p-6 mb-8">
      <h2 className="text-xl font-bold text-gray-900 mb-4">Performance Analysis</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Topic-wise Performance</h3>
          <div className="space-y-4">
            {topicPerformance.map((item, index) => (
              <div key={index}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">{item.topic}</span>
                  <span className="text-sm font-medium text-gray-700">{item.percentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="h-2.5 rounded-full" 
                    style={{ 
                      width: `${item.percentage}%`,
                      backgroundColor: subjectColor
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Strong & Weak Areas</h3>
          <div className="space-y-4">
            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="text-base font-medium text-green-700 mb-2">Strong Areas</h4>
              <ul className="space-y-1 text-sm text-gray-700">
                {strengthsWeaknesses.strong.map((item, index) => (
                  <li key={index} className="flex items-center">
                    <i className="fas fa-check-circle text-green-500 mr-2"></i> {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-red-50 p-4 rounded-lg">
              <h4 className="text-base font-medium text-red-700 mb-2">Areas to Improve</h4>
              <ul className="space-y-1 text-sm text-gray-700">
                {strengthsWeaknesses.weak.map((item, index) => (
                  <li key={index} className="flex items-center">
                    <i className="fas fa-times-circle text-red-500 mr-2"></i> {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceAnalysis;
