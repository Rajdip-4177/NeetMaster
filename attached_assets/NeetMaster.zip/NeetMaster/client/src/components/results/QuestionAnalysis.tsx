import { Question } from "@/context/QuizContext";
import { useQuiz } from "@/context/QuizContext";

interface QuestionAnalysisProps {
  question: Question;
  questionNumber: number;
  totalQuestions: number;
  subjectColor: string;
}

const QuestionAnalysis = ({ 
  question, 
  questionNumber, 
  totalQuestions,
  subjectColor 
}: QuestionAnalysisProps) => {
  const { toggleBookmark } = useQuiz();
  
  const isCorrect = question.selectedOptionId === question.correctOptionId;
  const isAnswered = question.selectedOptionId !== null;
  
  // Determine status label and color
  const getStatusInfo = () => {
    if (!isAnswered) {
      return {
        label: "Unanswered",
        bgColor: "bg-gray-100",
        textColor: "text-gray-800"
      };
    }
    
    if (isCorrect) {
      return {
        label: "Correct",
        bgColor: "bg-green-100",
        textColor: "text-green-800"
      };
    }
    
    return {
      label: "Incorrect",
      bgColor: "bg-red-100",
      textColor: "text-red-800"
    };
  };
  
  const status = getStatusInfo();

  return (
    <div className="border border-gray-200 rounded-lg mb-6 overflow-hidden">
      <div className="bg-gray-50 p-4 flex items-center justify-between">
        <div className="flex items-center">
          <span 
            className="text-white rounded-full w-7 h-7 flex items-center justify-center font-semibold mr-3"
            style={{ backgroundColor: subjectColor }}
          >
            {questionNumber}
          </span>
          <h3 className="font-medium text-gray-900">Question {questionNumber}</h3>
        </div>
        <div className="flex items-center">
          <span className={`${status.bgColor} ${status.textColor} text-xs font-medium py-1 px-2 rounded`}>
            {status.label}
          </span>
          <button 
            className={`${question.isBookmarked ? 'text-yellow-400' : 'text-gray-400 hover:text-yellow-500'} ml-3`}
            onClick={() => toggleBookmark(question.id)}
          >
            <i className={`${question.isBookmarked ? 'fas' : 'far'} fa-bookmark text-xl`}></i>
          </button>
        </div>
      </div>
      <div className="p-4">
        <p className="text-gray-800 mb-4">{question.questionText}</p>
        
        <div className="space-y-2 mb-4">
          {question.options.map(option => {
            const isSelected = option.id === question.selectedOptionId;
            const isCorrectOption = option.id === question.correctOptionId;
            
            return (
              <div key={option.id} className="flex items-start">
                <div className="flex-shrink-0 mt-0.5">
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center
                    ${isSelected && isCorrectOption ? 'bg-green-100 border border-green-600' : ''}
                    ${isSelected && !isCorrectOption ? 'bg-red-100 border border-red-600' : ''}
                    ${!isSelected && isCorrectOption ? 'bg-green-100 border border-green-600' : ''}
                    ${!isSelected && !isCorrectOption ? 'border border-gray-300' : ''}
                  `}>
                    {isSelected && isCorrectOption && <i className="fas fa-check text-xs text-green-600"></i>}
                    {isSelected && !isCorrectOption && <i className="fas fa-times text-xs text-red-600"></i>}
                    {!isSelected && isCorrectOption && <i className="fas fa-check text-xs text-green-600"></i>}
                  </div>
                </div>
                <div className="ml-3">
                  <span className="text-gray-800">{option.text}</span>
                  {isSelected && (
                    <span className={`text-xs ml-2 px-1.5 py-0.5 rounded
                      ${isCorrectOption ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}
                    `}>
                      Your answer
                    </span>
                  )}
                  {isCorrectOption && (
                    <span className="bg-green-100 text-green-800 text-xs ml-2 px-1.5 py-0.5 rounded">
                      Correct answer
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-medium text-gray-900 mb-2">Explanation</h4>
          <p className="text-gray-700 text-sm">
            {question.explanation}
          </p>
        </div>
      </div>
    </div>
  );
};

export default QuestionAnalysis;
