import { Link } from "wouter";

const Navbar = () => {
  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0 flex items-center">
              <svg
                className="h-8 w-8 text-[#10B981]"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
                <path d="M6 12v5c3 3 9 3 12 0v-5" />
              </svg>
              <span className="ml-2 text-xl font-bold text-gray-900">NEET Master</span>
            </Link>
          </div>
          <div className="flex items-center">
            <Link
              href="/bookmarks"
              className="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium"
            >
              <i className="fas fa-bookmark mr-1"></i> Bookmarks
            </Link>
            <Link
              href="/profile"
              className="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium"
            >
              <i className="fas fa-user-circle mr-1"></i> Profile
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
