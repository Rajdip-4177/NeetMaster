import { Link } from "wouter";
import { Chapter } from "@/data/chaptersData";

interface ChapterCardProps {
  chapter: Chapter;
  subjectColor: string;
  subjectSecondaryColor: string;
}

const ChapterCard = ({ chapter, subjectColor, subjectSecondaryColor }: ChapterCardProps) => {
  return (
    <Link href={`/${chapter.subjectId}/${chapter.id}`} className="group">
      <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 hover:border-[#10B981] transition-all duration-300">
        <div className="h-10" style={{ backgroundColor: subjectColor }}></div>
        <div className="p-6">
          <div className="flex justify-between items-start">
            <h2 
              className="text-xl font-semibold text-gray-900 group-hover:text-[#10B981] transition-colors duration-300"
              style={{ '--hover-color': subjectColor } as React.CSSProperties}
            >
              {chapter.title}
            </h2>
            <span 
              className="text-xs px-2 py-1 rounded-full"
              style={{ 
                backgroundColor: subjectSecondaryColor,
                color: subjectColor
              }}
            >
              Chapter {chapter.chapterNumber}
            </span>
          </div>
          <p className="text-gray-600 mt-2 mb-4">{chapter.description}</p>
          <div className="flex justify-between text-sm">
            <span className="flex items-center text-gray-500">
              <i className="fas fa-book-open mr-1"></i> {chapter.topicCount} Topics
            </span>
            <span className="flex items-center text-gray-500">
              <i className="fas fa-tasks mr-1"></i> {chapter.testCount} Tests
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ChapterCard;
