import { Link } from "wouter";

const Footer = () => {
  return (
    <footer className="bg-gray-100 mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">NEET Master</h3>
            <p className="text-gray-600 text-sm mb-4">
              Comprehensive preparation platform for NEET aspirants featuring subject-wise materials, tests, and performance analytics.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><Link href="/" className="hover:text-gray-900">Home</Link></li>
              <li><Link href="/biology" className="hover:text-gray-900">Biology</Link></li>
              <li><Link href="/physics" className="hover:text-gray-900">Physics</Link></li>
              <li><Link href="/chemistry" className="hover:text-gray-900">Chemistry</Link></li>
              <li><Link href="/bookmarks" className="hover:text-gray-900">Bookmarks</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Us</h3>
            <p className="text-gray-600 text-sm mb-4">
              Have questions or feedback? Reach out to our support team.
            </p>
            <a href="mailto:support@neetmaster.com" className="text-[#10B981] hover:text-[#0E9F6E]">
              support@neetmaster.com
            </a>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-200 text-center text-sm text-gray-500">
          <p>&copy; {new Date().getFullYear()} NEET Master. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
