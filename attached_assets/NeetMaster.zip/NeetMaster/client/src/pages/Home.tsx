import SubjectCard from "@/components/SubjectCard";
import { subjects } from "@/data/subjectsData";

const Home = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
          Prepare for NEET with Confidence
        </h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Comprehensive study materials, chapter-wise tests, and NCERT solutions to help you ace the NEET examination.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
        {subjects.map((subject) => (
          <SubjectCard key={subject.id} subject={subject} />
        ))}
      </div>

      <div className="mt-16 bg-white shadow-md rounded-lg p-8 max-w-5xl mx-auto">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Why Choose NEET Master?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-[#D1FAE5] rounded-full flex items-center justify-center mb-4">
              <i className="fas fa-book text-[#10B981] text-2xl"></i>
            </div>
            <h3 className="text-lg font-semibold mb-2">Comprehensive Coverage</h3>
            <p className="text-gray-600">Complete NCERT-aligned content with additional reference materials.</p>
          </div>
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-[#DBEAFE] rounded-full flex items-center justify-center mb-4">
              <i className="fas fa-tasks text-[#3B82F6] text-2xl"></i>
            </div>
            <h3 className="text-lg font-semibold mb-2">Chapter-wise Tests</h3>
            <p className="text-gray-600">Practice with focused mini-tests to master individual concepts.</p>
          </div>
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-[#EDE9FE] rounded-full flex items-center justify-center mb-4">
              <i className="fas fa-chart-line text-[#8B5CF6] text-2xl"></i>
            </div>
            <h3 className="text-lg font-semibold mb-2">Performance Analytics</h3>
            <p className="text-gray-600">Track your progress and identify areas needing improvement.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
