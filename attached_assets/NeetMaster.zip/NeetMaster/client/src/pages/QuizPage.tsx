import { useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { getSubjectById } from "@/data/subjectsData";
import { getChapterById } from "@/data/chaptersData";
import { getTestById, getQuestionsByTest } from "@/data/quizData";
import { useQuiz } from "@/context/QuizContext";
import QuestionBox from "@/components/quiz/QuestionBox";
import QuestionNavigator from "@/components/quiz/QuestionNavigator";
import Timer from "@/components/quiz/Timer";

const QuizPage = () => {
  const { subject, chapter, testId } = useParams();
  const [, setLocation] = useLocation();
  const { 
    startQuiz, 
    questions, 
    isQuizCompleted, 
    quizResult 
  } = useQuiz();
  
  const subjectData = getSubjectById(subject);
  const chapterData = getChapterById(chapter);
  const test = getTestById(parseInt(testId));
  
  // Redirect to results page if quiz is completed
  useEffect(() => {
    if (isQuizCompleted && quizResult) {
      setLocation(`/${subject}/${chapter}/test/${testId}/results`);
    }
  }, [isQuizCompleted, quizResult, subject, chapter, testId, setLocation]);
  
  // Initialize quiz when component mounts
  useEffect(() => {
    if (test) {
      const questionData = getQuestionsByTest(test.id);
      startQuiz(test.timeLimit, questionData);
    }
  }, [test, startQuiz]);

  if (!subjectData || !chapterData || !test) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center">
        <h1 className="text-3xl font-bold text-red-500">Test Not Found</h1>
        <p className="mt-4 text-gray-600">The test you're looking for doesn't exist.</p>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center">
        <h1 className="text-2xl font-bold text-gray-800">Loading Test...</h1>
      </div>
    );
  }

  const subjectColor = subjectData.primaryColor;
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Quiz Header */}
      <div className="bg-white shadow-md rounded-lg p-4 mb-6 flex flex-wrap justify-between items-center">
        <div className="flex items-center mb-2 md:mb-0">
          <div className={`w-10 h-10 bg-[${subjectColor}] rounded-full flex items-center justify-center text-white mr-3`}>
            {subject === 'biology' && <i className="fas fa-microscope"></i>}
            {subject === 'physics' && <i className="fas fa-atom"></i>}
            {subject === 'chemistry' && <i className="fas fa-flask"></i>}
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">{chapterData.title}</h1>
            <p className="text-gray-600 text-sm">Test {test.id}: {test.title}</p>
          </div>
        </div>
        <Timer />
      </div>

      {/* Quiz Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Question Box (75% on lg screens) */}
        <div className="lg:col-span-3">
          <QuestionBox subjectColor={subjectColor} />
        </div>

        {/* Question Navigation (25% on lg screens) */}
        <div className="lg:col-span-1">
          <QuestionNavigator subjectColor={subjectColor} />
        </div>
      </div>
    </div>
  );
};

export default QuizPage;
