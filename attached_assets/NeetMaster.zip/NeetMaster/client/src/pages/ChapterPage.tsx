import { useState } from "react";
import { useParams, Link } from "wouter";
import { getSubjectById } from "@/data/subjectsData";
import { getChapterById } from "@/data/chaptersData";
import { getTestsByChapter } from "@/data/quizData";
import TestCard from "@/components/TestCard";
import PDFViewer from "@/components/PDFViewer";

type TabType = "tests" | "notes" | "ncert";

const ChapterPage = () => {
  const { subject, chapter } = useParams();
  const [activeTab, setActiveTab] = useState<TabType>("tests");
  
  const subjectData = getSubjectById(subject);
  const chapterData = getChapterById(chapter);
  
  if (!subjectData || !chapterData) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-red-500">Chapter Not Found</h1>
          <p className="mt-4 text-gray-600">The chapter you're looking for doesn't exist.</p>
          <Link href="/" className="mt-4 inline-block text-blue-500 hover:underline">
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  const tests = getTestsByChapter(chapter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center">
          <Link href={`/${subject}`} className="text-gray-500 hover:text-gray-700 mr-2">
            <i className="fas fa-arrow-left"></i> Back to {subjectData.name}
          </Link>
        </div>
        <h1 className={`text-3xl font-bold text-[${subjectData.primaryColor}] mt-4`}>
          {chapterData.title}
        </h1>
        <p className="text-gray-600 mt-2">
          Study materials and tests for mastering {chapterData.title.toLowerCase()} concepts.
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="mb-8 border-b border-gray-200">
        <div className="flex flex-wrap -mb-px">
          <button 
            className={`mr-2 inline-block p-4 border-b-2 font-medium ${
              activeTab === "tests" 
                ? `border-[${subjectData.primaryColor}] text-[${subjectData.primaryColor}]` 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab("tests")}
          >
            <i className="fas fa-tasks mr-2"></i> Test Yourself
          </button>
          <button 
            className={`mr-2 inline-block p-4 border-b-2 font-medium ${
              activeTab === "notes" 
                ? `border-[${subjectData.primaryColor}] text-[${subjectData.primaryColor}]` 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab("notes")}
          >
            <i className="fas fa-book mr-2"></i> Notes
          </button>
          <button 
            className={`inline-block p-4 border-b-2 font-medium ${
              activeTab === "ncert" 
                ? `border-[${subjectData.primaryColor}] text-[${subjectData.primaryColor}]` 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab("ncert")}
          >
            <i className="fas fa-book-reader mr-2"></i> NCERT
          </button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="tab-content">
        {/* Test Yourself Tab */}
        {activeTab === "tests" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tests.map((test) => (
              <TestCard 
                key={test.id} 
                test={test} 
                subject={subject} 
                chapter={chapter}
                subjectColor={subjectData.primaryColor}
                subjectSecondaryColor={subjectData.secondaryColor}
              />
            ))}
          </div>
        )}

        {/* Notes Tab */}
        {activeTab === "notes" && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">{chapterData.title}: Study Notes</h2>
              <button className={`bg-[${subjectData.primaryColor}] hover:bg-opacity-90 text-white py-2 px-4 rounded-md flex items-center`}>
                <i className="fas fa-download mr-2"></i> Download PDF
              </button>
            </div>
            <PDFViewer 
              pdfType="notes" 
              subjectId={subject} 
              chapterId={chapter} 
              primaryColor={subjectData.primaryColor}
            />
          </div>
        )}

        {/* NCERT Tab */}
        {activeTab === "ncert" && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">NCERT {subjectData.name}: {chapterData.title}</h2>
              <button className={`bg-[${subjectData.primaryColor}] hover:bg-opacity-90 text-white py-2 px-4 rounded-md flex items-center`}>
                <i className="fas fa-download mr-2"></i> Download PDF
              </button>
            </div>
            <PDFViewer 
              pdfType="ncert" 
              subjectId={subject} 
              chapterId={chapter} 
              primaryColor={subjectData.primaryColor}
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default ChapterPage;
