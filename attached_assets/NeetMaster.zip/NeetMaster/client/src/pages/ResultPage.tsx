import { useEffect } from "react";
import { useParams, Link, useLocation } from "wouter";
import { getSubjectById } from "@/data/subjectsData";
import { getChapterById } from "@/data/chaptersData";
import { getTestById, getTopicPerformance, getStrengthsAndWeaknesses } from "@/data/quizData";
import { useQuiz } from "@/context/QuizContext";
import ScoreSummary from "@/components/results/ScoreSummary";
import PerformanceAnalysis from "@/components/results/PerformanceAnalysis";
import QuestionAnalysis from "@/components/results/QuestionAnalysis";

const ResultPage = () => {
  const { subject, chapter, testId } = useParams();
  const [, setLocation] = useLocation();
  const { quizResult, questions, isQuizCompleted } = useQuiz();
  
  const subjectData = getSubjectById(subject);
  const chapterData = getChapterById(chapter);
  const test = getTestById(parseInt(testId));
  
  // Redirect to chapter page if no quiz result is available
  useEffect(() => {
    if (!isQuizCompleted || !quizResult) {
      setLocation(`/${subject}/${chapter}`);
    }
  }, [isQuizCompleted, quizResult, subject, chapter, setLocation]);

  if (!subjectData || !chapterData || !test || !quizResult) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center">
        <h1 className="text-3xl font-bold text-red-500">Result Not Available</h1>
        <p className="mt-4 text-gray-600">No quiz results are available for this test.</p>
        <Link href={`/${subject}/${chapter}`} className="mt-4 inline-block text-blue-500 hover:underline">
          Return to Chapter
        </Link>
      </div>
    );
  }

  const topicPerformance = getTopicPerformance(parseInt(testId));
  const strengthsWeaknesses = getStrengthsAndWeaknesses(parseInt(testId));
  const subjectColor = subjectData.primaryColor;
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center">
          <Link href={`/${subject}/${chapter}`} className="text-gray-500 hover:text-gray-700 mr-2">
            <i className="fas fa-arrow-left"></i> Back to Chapter
          </Link>
        </div>
        <h1 className={`text-3xl font-bold text-[${subjectColor}] mt-4`}>
          Test Results: {test.title}
        </h1>
      </div>

      {/* Results Overview */}
      <ScoreSummary 
        quizResult={quizResult} 
        subjectColor={subjectColor} 
        subjectSecondaryColor={subjectData.secondaryColor}
      />

      {/* Detailed Analysis */}
      <PerformanceAnalysis 
        topicPerformance={topicPerformance}
        strengthsWeaknesses={strengthsWeaknesses}
        subjectColor={subjectColor}
      />

      {/* Question-wise Analysis */}
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Question-wise Analysis</h2>
        
        {questions.map((question, index) => (
          <QuestionAnalysis 
            key={question.id}
            question={question}
            questionNumber={index + 1}
            totalQuestions={questions.length}
            subjectColor={subjectColor}
          />
        ))}
      </div>
    </div>
  );
};

export default ResultPage;
