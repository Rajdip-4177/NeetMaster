import { useParams, Link } from "wouter";
import { getSubjectById } from "@/data/subjectsData";
import { getChaptersBySubject } from "@/data/chaptersData";
import ChapterCard from "@/components/ChapterCard";

const SubjectPage = () => {
  const { subject } = useParams();
  const subjectData = getSubjectById(subject);
  
  if (!subjectData) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-red-500">Subject Not Found</h1>
          <p className="mt-4 text-gray-600">The subject you're looking for doesn't exist.</p>
          <Link href="/" className="mt-4 inline-block text-blue-500 hover:underline">
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  const chapters = getChaptersBySubject(subject);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center">
          <Link href="/" className="text-gray-500 hover:text-gray-700 mr-2">
            <i className="fas fa-arrow-left"></i> Back to Home
          </Link>
        </div>
        <h1 className={`text-3xl font-bold text-[${subjectData.primaryColor}] mt-4`}>
          {subjectData.name} Chapters
        </h1>
        <p className="text-gray-600 mt-2">
          Select a chapter to access study materials, notes, and practice tests.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {chapters.map((chapter) => (
          <ChapterCard 
            key={chapter.id} 
            chapter={chapter} 
            subjectColor={subjectData.primaryColor}
            subjectSecondaryColor={subjectData.secondaryColor}
          />
        ))}
      </div>
    </div>
  );
};

export default SubjectPage;
