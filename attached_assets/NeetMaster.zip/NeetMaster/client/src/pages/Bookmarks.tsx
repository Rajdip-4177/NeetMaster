import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useQuiz } from "@/context/QuizContext";
import { getQuestionsByTest } from "@/data/quizData";
import { getTestById } from "@/data/quizData";
import { getChapterById } from "@/data/chaptersData";
import { getSubjectById } from "@/data/subjectsData";
import { Question } from "@/context/QuizContext";

interface BookmarkedQuestion extends Question {
  testId: number;
  chapterId: string;
  subjectId: string;
}

const Bookmarks = () => {
  const { bookmarkedQuestions, toggleBookmark } = useQuiz();
  const [bookmarkedItems, setBookmarkedItems] = useState<BookmarkedQuestion[]>([]);
  
  useEffect(() => {
    // This is a simplified approach to display bookmarks
    // In a real app, this data would come from a proper API
    const allBookmarkedQuestions: BookmarkedQuestion[] = [];
    
    // Iterate through each test to find bookmarked questions
    // Note: This is inefficient but works for demo purposes
    for (let testId = 1; testId <= 4; testId++) {
      const questions = getQuestionsByTest(testId);
      const test = getTestById(testId);
      
      if (test) {
        const chapter = getChapterById(test.chapterId);
        
        if (chapter) {
          const subject = getSubjectById(chapter.subjectId);
          
          if (subject) {
            questions.forEach(question => {
              if (bookmarkedQuestions.includes(question.id)) {
                allBookmarkedQuestions.push({
                  ...question,
                  testId,
                  chapterId: chapter.id,
                  subjectId: subject.id
                });
              }
            });
          }
        }
      }
    }
    
    setBookmarkedItems(allBookmarkedQuestions);
  }, [bookmarkedQuestions]);

  if (bookmarkedItems.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Your Bookmarked Questions</h1>
        <div className="bg-white shadow-md rounded-lg p-8 text-center">
          <div className="flex justify-center mb-4">
            <i className="far fa-bookmark text-4xl text-gray-400"></i>
          </div>
          <h2 className="text-xl font-semibold text-gray-700">No bookmarks yet</h2>
          <p className="text-gray-500 mt-2">
            You haven't bookmarked any questions yet. When taking tests, use the bookmark icon to save important questions for later review.
          </p>
          <Link href="/" className="mt-6 inline-block bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-md">
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Your Bookmarked Questions</h1>
      
      <div className="space-y-6">
        {bookmarkedItems.map((item) => {
          const subject = getSubjectById(item.subjectId);
          const chapter = getChapterById(item.chapterId);
          const test = getTestById(item.testId);
          
          if (!subject || !chapter || !test) return null;
          
          return (
            <div key={`${item.testId}-${item.id}`} className="bg-white shadow-md rounded-lg overflow-hidden border border-gray-200">
              <div className="bg-gray-50 p-4 flex items-center justify-between">
                <div>
                  <span className={`text-[${subject.primaryColor}] font-medium`}>{subject.name}</span>
                  <span className="mx-2 text-gray-400">•</span>
                  <span className="text-gray-700">{chapter.title}</span>
                  <span className="mx-2 text-gray-400">•</span>
                  <span className="text-gray-700">{test.title}</span>
                </div>
                <button 
                  onClick={() => toggleBookmark(item.id)}
                  className="text-yellow-400 hover:text-yellow-500"
                >
                  <i className="fas fa-bookmark text-xl"></i>
                </button>
              </div>
              <div className="p-4">
                <p className="text-gray-800 mb-4">{item.questionText}</p>
                
                <div className="space-y-2 mb-4">
                  {item.options.map(option => (
                    <div key={option.id} className="flex items-start">
                      <div className="flex-shrink-0 mt-0.5">
                        <div className={`w-5 h-5 border border-gray-300 rounded-full ${
                          option.id === item.correctOptionId ? 'bg-green-100 border-green-600' : ''
                        }`}>
                          {option.id === item.correctOptionId && (
                            <i className="fas fa-check text-xs text-green-600 flex items-center justify-center h-full"></i>
                          )}
                        </div>
                      </div>
                      <div className="ml-3">
                        <span className="text-gray-800">{option.text}</span>
                        {option.id === item.correctOptionId && (
                          <span className="bg-green-100 text-green-800 text-xs ml-2 px-1.5 py-0.5 rounded">Correct answer</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Explanation</h4>
                  <p className="text-gray-700 text-sm">
                    {item.explanation}
                  </p>
                </div>
                
                <div className="mt-4 flex justify-end">
                  <Link 
                    href={`/${item.subjectId}/${item.chapterId}/test/${item.testId}`}
                    className={`text-[${subject.primaryColor}] hover:underline text-sm flex items-center`}
                  >
                    Take Full Test <i className="fas fa-arrow-right ml-1"></i>
                  </Link>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Bookmarks;
