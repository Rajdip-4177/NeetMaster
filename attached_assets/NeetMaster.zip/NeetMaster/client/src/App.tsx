import { Route, Switch } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import SubjectPage from "@/pages/SubjectPage";
import ChapterPage from "@/pages/ChapterPage";
import QuizPage from "@/pages/QuizPage";
import ResultPage from "@/pages/ResultPage";
import Bookmarks from "@/pages/Bookmarks";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { QuizProvider } from "@/context/QuizContext";

function App() {
  return (
    <QuizProvider>
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/bookmarks" component={Bookmarks} />
            <Route path="/:subject" component={SubjectPage} />
            <Route path="/:subject/:chapter" component={ChapterPage} />
            <Route path="/:subject/:chapter/test/:testId" component={QuizPage} />
            <Route path="/:subject/:chapter/test/:testId/results" component={ResultPage} />
            <Route component={NotFound} />
          </Switch>
        </main>
        <Footer />
        <Toaster />
      </div>
    </QuizProvider>
  );
}

export default App;
